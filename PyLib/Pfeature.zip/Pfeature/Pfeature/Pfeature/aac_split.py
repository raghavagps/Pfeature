import pandas as pd
import sys
import os
import numpy as np
import math
from itertools import repeat
std = list("ACDEFGHIKLMNPQRSTVWY")
def aac_split(file):
    filename,file_ext = os.path.splitext(file)
    df1 = pd.read_csv(file, header = None)
    df2 = pd.DataFrame(df1[0].str.upper())
    k1 = []
    for w in range(0,len(df2)):
        s = 0
        k2 = []
        r = 0
        if len(df2[0][w])%3 == 0:
            k2.extend(repeat(int(len(df2[0][w])/3),3))
        else:
            r = int(len(df2[0][w])%3)
            k2.extend(repeat(int(len(df2[0][w])/3),2))
            k2.append((int(len(df2[0][w])/3)+r))
        for j in k2:
            df3 = df2[0][w][s:j+s]
            k1.append(df3)
            s = j+s
    f = open(filename+".out_split", 'w')
    sys.stdout = f
    print("As1,Cs1,Ds1,Es1,Fs1,Gs1,Hs1,Is1,Ks1,Ls1,Ms1,Ns1,Ps1,Qs1,Rs1,Ss1,Ts1,Vs1,Ws1,Ys1,As2,Cs2,Ds2,Es2,Fs2,Gs2,Hs2,Is2,Ks2,Ls2,Ms2,Ns2,Ps2,Qs2,Rs2,Ss2,Ts2,Vs2,Ws2,Ys2,As3,Cs3,Ds3,Es3,Fs3,Gs3,Hs3,Is3,Ks3,Ls3,Ms3,Ns3,Ps3,Qs3,Rs3,Ss3,Ts3,Vs3,Ws3,Ys3,")
    for i in range(0,len(k1),3):
        k4 = k1[i:i+3]
        for j in k4:
            for i in std:
                count = 0
                for m in j:
                    temp1 = m
                    if temp1 == i:
                        count +=1
                    composition = (count/len(j))*100
                print ("%.2f"%composition, end = ",")
        print ("")  
    f.truncate()
