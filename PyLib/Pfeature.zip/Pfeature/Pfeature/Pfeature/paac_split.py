import pandas as pd
import os
import math
import sys
from itertools import repeat
data1 = pd.read_csv("data", sep = "\t")
std = list('ACDEFGHIKLMNPQRSTVWY')
def val(AA_1, AA_2, aa, mat):
    return sum([(mat[i][aa[AA_1]] - mat[i][aa[AA_2]]) ** 2 for i in range(len(mat))]) / len(mat)
def paac_1(file,lambdaval=5,v=3,w=0.05):
    filename, file_extension = os.path.splitext(file)
    df = pd.read_csv(file, header = None)
    df2 = pd.DataFrame(df[0].str.upper())
    k1 = []
    for w in range(0,len(df2)):
        s = 0
        k2 = []
        r = 0
        if len(df2[0][w])%v == 0:
            k2.extend(repeat(int(len(df2[0][w])/v),v))
        else:
            r = int(len(df2[0][w])%v)
            k2.extend(repeat(int(len(df2[0][w])/v),v-1))
            k2.append((int(len(df2[0][w])/v))+r)
        for j in k2:
            df3 = df2[0][w][s:j+s]
            k1.append(df3)
            s = j+s
    df4 = pd.DataFrame(k1)
    df4.to_csv(filename+".split", index = None, header = False, encoding = 'utf-8')
    df1 = pd.read_csv(filename+".split", header = None)
    dd = []
    cc = []
    pseudo = []
    for t in range(0,len(df1)):
        if lambdaval >= len(df1[0][t]):
            print("Error: Value of lambda should be less than the length of the peptide.")
        else:	
            aa = {}
            for i in range(len(std)):
                aa[std[i]] = i
            for i in range(0,3):
                mean = sum(data1.iloc[i][1:])/20
                rr = math.sqrt(sum([(p-mean)**2 for p in data1.iloc[i][1:]])/20)
                dd.append([(p-mean)/rr for p in data1.iloc[i][1:]])
                zz = pd.DataFrame(dd)
            head = []
            for n in range(1, lambdaval + 1):
                head.append('lam_' + str(n))
            pp = pd.DataFrame()
            ee = []
            for k in range(0,len(df1)):
                cc = [] 
                for n in range(1,lambdaval+1):
                    cc.append(sum([val(df1[0][k][p], df1[0][k][p + n], aa, dd) for p in range(len(df1[0][k]) - n)]) / (len(df1[0][k]) - n))
                    qq = pd.DataFrame(cc)
                pseudo = [(w * p) / (1 + w * sum(cc)) for p in cc]
                ee.append(pseudo)
                ii = round(pd.DataFrame(ee, columns = head),4)
                ii.to_csv(filename+".lam_split",index = None)
def aac_comp(file,n=0):
    filename, file_extension = os.path.splitext(file)
    f = open(filename+".aac", 'w')
    sys.stdout = f
    if n > 0 :
        xx = n_mers(file,n)
        xx.to_csv(filename+".mers")
        zz = xx.iloc[:,2]
    else :
        df = pd.read_csv(file, header = None)
        zz = df.iloc[:,0]
    print("A,C,D,E,F,G,H,I,K,L,M,N,P,Q,R,S,T,V,W,Y,")
    for j in zz:
        for i in std:
            count = 0
            for k in j:
                temp1 = k
                if temp1 == i:
                    count += 1
                composition = (count/len(j))
            print("%.4f"%composition, end = ",")
        print("")
    f.truncate()
def paac_split(file,lambdaval=5,v=3,w=0.05):
    filename, file_extension = os.path.splitext(file)
    paac_1(file,lambdaval=5,v=3,w=0.05)
    aac_comp(filename+".split")
    data1 = pd.read_csv(filename+".aac")
    data2 = pd.read_csv(filename+".lam_split")
    df3 = pd.concat([data1.iloc[:,:-1],data2], axis = 1).reset_index(drop=True)
    header = ['A_s1','C_s1','D_s1','E_s1','F_s1','G_s1','H_s1','I_s1','K_s1','L_s1','M_s1','N_s1','P_s1','Q_s1','R_s1','S_s1','T_s1','V_s1','W_s1','Y_s1','lam_1_s1','lam_2_s1','lam_3_s1','lam_4_s1','lam_5_s1','A_s2','C_s2','D_s2','E_s2','F_s2','G_s2','H_s2','I_s2','K_s2','L_s2','M_s2','N_s2','P_s2','Q_s2','R_s2','S_s2','T_s2','V_s2','W_s2','Y_s2','lam_1_s2','lam_2_s2','lam_3_s2','lam_4_s2','lam_5_s2','A_s3','C_s3','D_s3','E_s3','F_s3','G_s3','H_s3','I_s3','K_s3','L_s3','M_s3','N_s3','P_s3','Q_s3','R_s3','S_s3','T_s3','V_s3','W_s3','Y_s3','lam_1_s3','lam_2_s3','lam_3_s3','lam_4_s3','lam_5_s3',]
    zz = pd.DataFrame()
    for i in range(0,len(df3),3):
        zz = zz.append(pd.DataFrame(pd.concat([df3.loc[i],df3.loc[i+1],df3.loc[i+2]],axis=0)).transpose()).reset_index(drop=True) 
    zz.columns = header
    zz.to_csv(filename+".paac_split", index = None)
