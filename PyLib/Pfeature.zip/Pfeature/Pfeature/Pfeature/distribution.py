import pandas as pd
import os
import sys
def test(file):
    filename, file_ext = os.path.splitext(file)
    head3 = []
    header3 = ['0%','25%','50%','75%','100%']
    header4 = ['Hydrophobicity','NVWV','Polarity','Polarizability','Charge','SS','SA']
    for j in range(1,4):
        for k in header4:
            for i in header3:
                head3.append(i+'_'+str(j)+'_'+k)
    df_3 = pd.read_csv(filename+".dist", sep=" ")
    rr = pd.DataFrame()
    for i in range(0,len(df_3),21):
        rr = rr.append(pd.DataFrame(pd.concat([df_3.loc[i],df_3.loc[i+1],df_3.loc[i+2],df_3.loc[i+3],df_3.loc[i+4],df_3.loc[i+5],df_3.loc[i+6],df_3.loc[i+7],df_3.loc[i+8],df_3.loc[i+9],df_3.loc[i+10],df_3.loc[i+11],df_3.loc[i+12],df_3.loc[i+13],df_3.loc[i+14],df_3.loc[i+15],df_3.loc[i+16],df_3.loc[i+17],df_3.loc[i+18],df_3.loc[i+19],df_3.loc[i+20]],axis=0)).transpose()).reset_index(drop=True)
    rr.columns = head3
    rr.to_csv(filename+".ctd_dist", index=None, encoding='utf-8')
file=sys.argv[1]
test(file)
