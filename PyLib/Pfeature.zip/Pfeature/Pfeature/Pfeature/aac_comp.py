import pandas as pd
import sys
import os
import numpy as np
std = list("ACDEFGHIKLMNPQRSTVWY")
def aac_comp(file,n=0):
    filename, file_extension = os.path.splitext(file)
    f = open(filename+".aac", 'w')
    sys.stdout = f
    if n > 0 :
        xx = n_mers(file,n)
        xx.to_csv(filename+".mers")
        zz = xx.iloc[:,2]
    else :
        df = pd.read_csv(file, header = None)
        zz = df.iloc[:,0]
    print("A,C,D,E,F,G,H,I,K,L,M,N,P,Q,R,S,T,V,W,Y,")
    for j in zz:
        for i in std:
            count = 0
            for k in j:
                temp1 = k
                if temp1 == i:
                    count += 1
                composition = (count/len(j))*100
            print("%.2f"%composition, end = ",")
        print("")
    f.truncate()
