import pandas as pd
import os
import math
import sys
data1 = pd.read_csv("data", sep = "\t")
std = list('ACDEFGHIKLMNPQRSTVWY')
def val(AA_1, AA_2, aa, mat):
    return sum([(mat[i][aa[AA_1]] - mat[i][aa[AA_2]]) ** 2 for i in range(len(mat))]) / len(mat)
def paac_1(file,lambdaval,v,w=0.05):
    filename, file_extension = os.path.splitext(file)
    df = pd.read_csv(file, header = None)
    df2 = pd.DataFrame(df[0].str.upper())
    df3 = []
    for i in range(0,len(df2)):
        df3.append(df2[0][i][-v:])
        df4 = pd.DataFrame(df3)
        df4.to_csv(filename+".ct", index = None, header = False, encoding = 'utf-8')
    df1 = pd.read_csv(filename+".ct", header = None)
    dd = []
    cc = []
    pseudo = []
    if lambdaval >= v:
       print("Error: Value of lambda should be less than the length of the C-terminal.")
    else:		
        aa = {}
        for i in range(len(std)):
            aa[std[i]] = i
        for i in range(0,3):
            mean = sum(data1.iloc[i][1:])/20
            rr = math.sqrt(sum([(p-mean)**2 for p in data1.iloc[i][1:]])/20)
            dd.append([(p-mean)/rr for p in data1.iloc[i][1:]])
            zz = pd.DataFrame(dd)
        head = []
        for n in range(1, lambdaval + 1):
            head.append('lam_' + str(n))
        pp = pd.DataFrame()
        ee = []
        for k in range(0,len(df1)):
            cc = [] 
            for n in range(1,lambdaval+1):
                cc.append(sum([val(df1[0][k][p], df1[0][k][p + n], aa, dd) for p in range(len(df1[0][k]) - n)]) / (len(df1[0][k]) - n))
                qq = pd.DataFrame(cc)
            pseudo = [(w * p) / (1 + w * sum(cc)) for p in cc]
            ee.append(pseudo)
            ii = round(pd.DataFrame(ee, columns = head),4)
            ii.to_csv(filename+".lam_ct",index = None)
def aac_comp(file,n=0):
    filename, file_extension = os.path.splitext(file)
    f = open(filename+".aac", 'w')
    sys.stdout = f
    if n > 0 :
        xx = n_mers(file,n)
        xx.to_csv(filename+".mers")
        zz = xx.iloc[:,2]
    else :
        df = pd.read_csv(file, header = None)
        zz = df.iloc[:,0]
    print("A,C,D,E,F,G,H,I,K,L,M,N,P,Q,R,S,T,V,W,Y,")
    for j in zz:
        for i in std:
            count = 0
            for k in j:
                temp1 = k
                if temp1 == i:
                    count += 1
                composition = (count/len(j))
            print("%.4f"%composition, end = ",")
        print("")
    f.truncate()
def paac_nt(file,lambdaval,v,w=0.05):
    filename, file_extension = os.path.splitext(file)
    paac_1(file,lambdaval,v,w=0.05)
    aac_comp(filename+".ct")
    data1 = pd.read_csv(filename+".aac")
    data2 = pd.read_csv(filename+".lam_ct")
    data3 = pd.concat([data1.iloc[:,:-1],data2], axis = 1).reset_index(drop=True)
    data3.to_csv(filename+".paac_ct", index = None)

