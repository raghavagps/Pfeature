import pandas as pd
import os
import sys
def dist(file):
    filename, file_ext = os.path.splitext(file)
    head3 = []
    header3 = ['0%','25%','50%','75%','100%']
    for j in range(1,4):
        for k in header3:
            head3.append("gp"+str(j)+'_'+k)
    df_3 = pd.read_csv(filename+".dist", sep=" ")
    rr = pd.DataFrame()
    for i in range(0,len(df_3),3):
        rr = rr.append(pd.DataFrame(pd.concat([df_3.loc[i],df_3.loc[i+1],df_3.loc[i+2]],axis=0)).transpose()).reset_index(drop=True)
    rr.columns = head3
    rr.to_csv(filename+".dist_1", index=None, encoding='utf-8')
file=sys.argv[1]
dist(file)
