import pandas as pd
import os
import math
import sys
import getopt
data1 = pd.read_csv("Data/data", sep = "\t")
from itertools import repeat

def split(file,v):
    filename, file_extension = os.path.splitext(file)
    df1 = pd.read_csv(file, header = None)
    df2 = pd.DataFrame(df1[0].str.upper())
    k1 = []
    for w in range(0,len(df2)):
        s = 0
        k2 = []
        r = 0
        if len(df2[0][w])%v == 0:
            k2.extend(repeat(int(len(df2[0][w])/v),v))
        else:
            r = int(len(df2[0][w])%v)
            k2.extend(repeat(int(len(df2[0][w])/v),v-1))
            k2.append((int(len(df2[0][w])/v))+r)
        for j in k2:
            df3 = df2[0][w][s:j+s]
            k1.append(df3)
            s = j+s
    df4 = pd.DataFrame(k1)
    #df4.to_csv(filename+".split", index = None, header = False, encoding = 'utf-8')
    return df4	
std = list('ACDEFGHIKLMNPQRSTVWY')
def apaac_1_split(file,lambdaval,v):
    w=0.05
    df1 = split(file,v)
    filename, file_extension = os.path.splitext(file)
    #df = pd.read_csv(file, header = None)
    #df1 = pd.DataFrame(df[0].str.upper())
    dd = []
    cc = []
    pseudo = []
    aa = {}
    for i in range(len(std)):
        aa[std[i]] = i
    for i in range(0,3):
        mean = sum(data1.iloc[i][1:])/20
        rr = math.sqrt(sum([(p-mean)**2 for p in data1.iloc[i][1:]])/20)
        dd.append([(p-mean)/rr for p in data1.iloc[i][1:]])
        zz = pd.DataFrame(dd)
    head = []
    for n in range(1, lambdaval + 1):
        for e in ('hydrphobicity','hydrophilicity','sidechainmass'):
            head.append('lam_' + str(n)+"_"+str(e))
    pp = pd.DataFrame()
    ee = []
    for k in range(0,len(df1)):
        cc = [] 
        for n in range(1,lambdaval+1):
            for b in range(0,len(zz)):
                cc.append(sum([zz.loc[b][aa[df1[0][k][p]]] * zz.loc[b][aa[df1[0][k][p + n]]] for p in range(len(df1[0][k]) - n)]) / (len(df1[0][k]) - n))
                qq = pd.DataFrame(cc)
        pseudo = [(w * p) / (1 + w * sum(cc)) for p in cc]
        ee.append(pseudo)
        ii = round(pd.DataFrame(ee, columns = head),4)
        ii.to_csv(filename+".plam",index = None)
def aac_comp(file,v):
    df = split(file,v)
    filename, file_extension = os.path.splitext(file)
    f = open(filename+".aac", 'w')
    sys.stdout = f
    zz = df.iloc[:,0]
    print("A,C,D,E,F,G,H,I,K,L,M,N,P,Q,R,S,T,V,W,Y,")
    for j in zz:
        for i in std:
            count = 0
            for k in j:
                temp1 = k
                if temp1 == i:
                    count += 1
                composition = (count/len(j))
            print("%.4f"%composition, end = ",")
        print("")
    f.truncate()
def apaac_split(file,output,lambdaval,v):
    filename, file_extension = os.path.splitext(file)
    apaac_1_split(file,lambdaval,v)
    aac_comp(file,v)
    data1 = pd.read_csv(filename+".aac")
    data2 = pd.read_csv(filename+".plam")
    df3 = pd.concat([data1.iloc[:,:-1],data2], axis = 1).reset_index(drop=True)
    header = []
    header1 = ('hydrphobicity','hydrophilicity','sidechainmass')
    for h in range(1,v+1):
        for e in std:
            header.append(e+"_s"+str(h))
        for r in range(1,lambdaval+1):
            for s in header1:
                header.append("lam_"+str(r)+"_"+s+"_s"+str(h))
    bb = []
    for i in range(0,len(df3),v):
        aa = []
        for j in range(v):
            aa.extend(df3.loc[i+j])
        bb.append(aa)
    zz = pd.DataFrame(bb)
    zz.columns = header
    zz.to_csv(output, index = None)    
    zz.columns=header
    zz.to_csv(output, index = None)
    os.remove(filename+".plam")
    os.remove(filename+".aac")
def main(argv):
    global inputfile
    global outputfile
    inputfile = ''
    outputfile = ''
    number1 = 5
    number2 = 1
    if len(argv[1:]) == 0:
        print ("\nUsage: apaac_split.py -i inputfile -o outputfile  -l lambda -n Number_of_splits\n")
        print("-i: Input file in single line format\n-o: Output file\n-l: lambda value\n-n: Number of splits\n")
        sys.exit()

    if len(argv[1:])<7:
        print ("\nUsage: apaac_split.py -i inputfile -o outputfile  -l lambda -n Number_of_splits\n")
        print("-i: Input file in single line format\n-o: Output file\n-l: lambda value\n-n: Number of splits\n")
        print("\nInputError: You have provided lesser number of arguments. \n")
        sys.exit()
    try:
      opts, args = getopt.getopt(argv,"i:o:l:n:w:",["ifile=","ofile=","n1=","n2="])
    except getopt.GetoptError:
        print ("\nUsage: apaac_split.py -i inputfile -o outputfile  -l lambda -n Number_of_splits\n")
        sys.exit(2)
    for opt, arg in opts:
        if opt == '--help' or opt == '--h':
            print ('\napaac_split.py -i inputfile -o outputfile  -l lambda -n Number_of_splits')
            print('inputfile : file of peptide/protein sequences for which descriptors need to be generated\n')
            print('outputfile : is the file of feature vectors\n')
            print('lambda : is the value of the lambda\n')
            print('Number_of_splits : Number of splits\n')
            sys.exit()
        elif opt in ("-i", "--ifile"):
            inputfile = arg
        elif opt in ("-o", "--ofile"):
            outputfile = arg
        elif opt in ("-l", "-n1"):
            n1 = int(sys.argv[6])
        elif opt in ("-n", "-n2"):
            n2 = int(sys.argv[8])
    apaac_split(sys.argv[2],sys.argv[4],int(sys.argv[6]),int(sys.argv[8]))
if __name__ == '__main__':
    #print(sys.argv)
    main(sys.argv[1:])
