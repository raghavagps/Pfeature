import pandas as pd
import os
import math
import sys
data1 = pd.read_csv("data", sep = "\t")
from itertools import repeat

def split(file,v=3):
    filename, file_extension = os.path.splitext(file)
    df1 = pd.read_csv(file, header = None)
    df2 = pd.DataFrame(df1[0].str.upper())
    k1 = []
    for w in range(0,len(df2)):
        s = 0
        k2 = []
        r = 0
        if len(df2[0][w])%v == 0:
            k2.extend(repeat(int(len(df2[0][w])/v),v))
        else:
            r = int(len(df2[0][w])%v)
            k2.extend(repeat(int(len(df2[0][w])/v),v-1))
            k2.append((int(len(df2[0][w])/v))+r)
        for j in k2:
            df3 = df2[0][w][s:j+s]
            k1.append(df3)
            s = j+s
    df4 = pd.DataFrame(k1)
    #df4.to_csv(filename+".split", index = None, header = False, encoding = 'utf-8')
    return df4	
std = list('ACDEFGHIKLMNPQRSTVWY')
def apaac_1_split(file,lambdaval=5,v=3):
    w=0.05
    df1 = split(file,v)
    filename, file_extension = os.path.splitext(file)
    #df = pd.read_csv(file, header = None)
    #df1 = pd.DataFrame(df[0].str.upper())
    dd = []
    cc = []
    pseudo = []
    aa = {}
    for i in range(len(std)):
        aa[std[i]] = i
    for i in range(0,3):
        mean = sum(data1.iloc[i][1:])/20
        rr = math.sqrt(sum([(p-mean)**2 for p in data1.iloc[i][1:]])/20)
        dd.append([(p-mean)/rr for p in data1.iloc[i][1:]])
        zz = pd.DataFrame(dd)
        print(zz)
    head = []
    for n in range(1, lambdaval + 1):
        for e in ('hydrphobicity','hydrophilicity','sidechainmass'):
            head.append('lam_' + str(n)+"_"+str(e))
    pp = pd.DataFrame()
    ee = []
    for k in range(0,len(df1)):
        cc = [] 
        for n in range(1,lambdaval+1):
            for b in range(0,len(zz)):
                cc.append(sum([zz.loc[b][aa[df1[0][k][p]]] * zz.loc[b][aa[df1[0][k][p + n]]] for p in range(len(df1[0][k]) - n)]) / (len(df1[0][k]) - n))
                qq = pd.DataFrame(cc)
        pseudo = [(w * p) / (1 + w * sum(cc)) for p in cc]
        ee.append(pseudo)
        ii = round(pd.DataFrame(ee, columns = head),4)
        ii.to_csv(filename+".plam",index = None)
def aac_comp(file,v=3):
    df = split(file,v)
    filename, file_extension = os.path.splitext(file)
    f = open(filename+".aac", 'w')
    sys.stdout = f
    zz = df.iloc[:,0]
    print("A,C,D,E,F,G,H,I,K,L,M,N,P,Q,R,S,T,V,W,Y,")
    for j in zz:
        for i in std:
            count = 0
            for k in j:
                temp1 = k
                if temp1 == i:
                    count += 1
                composition = (count/len(j))
            print("%.4f"%composition, end = ",")
        print("")
    f.truncate()
def apaac_split(file,lambdaval=5,n=3):
    filename, file_extension = os.path.splitext(file)
    apaac_1_split(file,lambdaval=5,v=3)
    aac_comp(file)
    data1 = pd.read_csv(filename+".aac")
    data2 = pd.read_csv(filename+".plam")
    df = pd.concat([data1.iloc[:,:-1],data2], axis = 1).reset_index(drop=True)
    header = ['A_s1','C_s1','D_s1','E_s1','F_s1','G_s1','H_s1','I_s1','K_s1','L_s1','M_s1','N_s1','P_s1','Q_s1','R_s1','S_s1','T_s1','V_s1','W_s1','Y_s1','lam_1_hydrphobicity_s1','lam_1_hydrophilicity_s1','lam_1_sidechainmass_s1','lam_2_hydrphobicity_s1','lam_2_hydrophilicity_s1','lam_2_sidechainmass_s1','lam_3_hydrphobicity_s1','lam_3_hydrophilicity_s1','lam_3_sidechainmass_s1','lam_4_hydrphobicity_s1','lam_4_hydrophilicity_s1','lam_4_sidechainmass_s1','lam_5_hydrphobicity_s1','lam_5_hydrophilicity_s1','lam_5_sidechainmass_s1','A_s2','C_s2','D_s2','E_s2','F_s2','G_s2','H_s2','I_s2','K_s2','L_s2','M_s2','N_s2','P_s2','Q_s2','R_s2','S_s2','T_s2','V_s2','W_s2','Y_s2','lam_1_hydrphobicity_s2','lam_1_hydrophilicity_s2','lam_1_sidechainmass_s2','lam_2_hydrphobicity_s2','lam_2_hydrophilicity_s2','lam_2_sidechainmass_s2','lam_3_hydrphobicity_s2','lam_3_hydrophilicity_s2','lam_3_sidechainmass_s2','lam_4_hydrphobicity_s2','lam_4_hydrophilicity_s2','lam_4_sidechainmass_s2','lam_5_hydrphobicity_s2','lam_5_hydrophilicity_s2','lam_5_sidechainmass_s2','A_s3','C_s3','D_s3','E_s3','F_s3','G_s3','H_s3','I_s3','K_s3','L_s3','M_s3','N_s3','P_s3','Q_s3','R_s3','S_s3','T_s3','V_s3','W_s3','Y_s3','lam_1_hydrphobicity_s3','lam_1_hydrophilicity_s3','lam_1_sidechainmass_s3','lam_2_hydrphobicity_s3','lam_2_hydrophilicity_s3','lam_2_sidechainmass_s3','lam_3_hydrphobicity_s3','lam_3_hydrophilicity_s3','lam_3_sidechainmass_s3','lam_4_hydrphobicity_s3','lam_4_hydrophilicity_s3','lam_4_sidechainmass_s3','lam_5_hydrphobicity_s3','lam_5_hydrophilicity_s3','lam_5_sidechainmass_s3',]
    zz = pd.DataFrame()
    for i in range(0,len(df),3):
        zz = zz.append(pd.DataFrame(pd.concat([df.loc[i],df.loc[i+1],df.loc[i+2]],axis=0)).transpose()).reset_index(drop=True)
    zz.columns=header
    zz.to_csv(filename+".apaac", index = None)
    os.remove(filename+".plam")
    os.remove(filename+".aac")
